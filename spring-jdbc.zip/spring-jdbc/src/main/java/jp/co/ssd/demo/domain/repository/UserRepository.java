package jp.co.ssd.demo.domain.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.EmptySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import jp.co.ssd.demo.domain.entity.User;

@Component
public class UserRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<User> findAll() {
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM USERS", 
                EmptySqlParameterSource.INSTANCE,
                new BeanPropertyRowMapper<User>(User.class));
    }

    public List<User> findByUserNameLike(String userName) {
        MapSqlParameterSource key = new MapSqlParameterSource();
        key.addValue("userName", "%" + userName + "%");
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM USERS WHERE USER_NAME LIKE :userName", 
                key,
                new BeanPropertyRowMapper<User>(User.class));
    }

    public List<User> findAll(String userId, String userName, String userEmail) {
        MapSqlParameterSource key = new MapSqlParameterSource();
        String sql = "SELECT * FROM USERS WHERE 1 = 1";
        if (!StringUtils.isEmpty(userId)) {
            sql = sql + " AND USER_ID = :userId";
            key.addValue("userId", userId);
        }
        if (!StringUtils.isEmpty(userName)) {
            sql = sql + " AND USER_NAME = :userName";
            key.addValue("userName", userName);
        }
        if (!StringUtils.isEmpty(userEmail)) {
            sql = sql + " AND USER_MAIL = :userEmail";
            key.addValue("userEmail", userEmail);
        }
        return namedParameterJdbcTemplate.query(
                sql, 
                key,
                new BeanPropertyRowMapper<User>(User.class));
    }

    public List<User> findByUserId(String userId) {
        MapSqlParameterSource key = new MapSqlParameterSource();
        key.addValue("userId", userId);
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM USERS WHERE USER_ID = :userId", 
                key,
                new BeanPropertyRowMapper<User>(User.class));
    }

    public void delete(String userId) {
        SqlParameterSource param = new MapSqlParameterSource().addValue("userId", userId);
        namedParameterJdbcTemplate
            .update("DELETE FROM USERS WHERE user_id = :userId", param);
    }

    public void insert(User user) {
        SqlParameterSource param = new BeanPropertySqlParameterSource(user);
        SimpleJdbcInsert insert =
                new SimpleJdbcInsert(namedParameterJdbcTemplate.getJdbcTemplate())
                .withTableName("USERS").usingGeneratedKeyColumns("user_serial_Id");
        insert.execute(param);
    }

    public User findOne(Long userSerialId) {
        MapSqlParameterSource key = new MapSqlParameterSource();
        key.addValue("userSerialId", userSerialId);
        return namedParameterJdbcTemplate.queryForObject(
                "SELECT * FROM USERS WHERE USER_SERIAL_ID = :userSerialId", 
                key,
                new BeanPropertyRowMapper<User>(User.class));
    }

    public void update(User user) {
        SqlParameterSource param = new BeanPropertySqlParameterSource(user);
        namedParameterJdbcTemplate.update(
                "UPDATE USERS SET "
                + " USER_NAME = :userName"
                + ",USER_ID = :userId"
                + ",USER_MAIL = :userMail"
                + " WHERE USER_SERIAL_ID = :userSerialId", 
                param);
        
    }
}