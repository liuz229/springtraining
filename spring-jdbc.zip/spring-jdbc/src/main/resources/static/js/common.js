// (c) 2017 Sompo Japan Nipponkoa Insurance Inc.
/**
 * JavaScriptで使用するオブジェクトのルート
 *
 * @namespace root
 */
var root = root || {};
/**
 * UI共通部品で使用するオブジェクトのルート
 *
 * @namespace root.ui
 */
root.ui = root.ui || {};
/**
 * アプリに公開するAPIを定義するオブジェクトのルート
 *
 * @namespace root.util
 */
root.util = root.util || {};
/**
 * フッタで使用するオブジェクトのルート
 *
 * @namespace root.ui.footer
 */
root.ui.footer = root.ui.footer || {};
/**
 * フォーカス移動で使用するオブジェクトのルート
 *
 * @namespace root.ui.focus
 */
root.ui.focus = root.ui.focus || {};
/**
 * ヘッダで使用するオブジェクトのルート
 *
 * @namespace root.ui.header
 */
root.ui.header = root.ui.header || {};
/**
 * リンクで使用するオブジェクトのルート
 *
 * @namespace root.ui.link
 */
root.ui.link = root.ui.link || {};
/**
 * inputTextで使用するオブジェクトのルート
 *
 * @namespace root.ui.inputText
 */
root.ui.inputText = root.ui.inputText || {};
/**
 * 電話番号用テキストボックスで使用するオブジェクトのルート
 *
 * @namespace root.ui.inputPhoneNumber
 */
root.ui.inputPhoneNumber = root.ui.inputPhoneNumber || {};
/**
 * 郵便番号用テキストボックスで使用するオブジェクトのルート
 *
 * @namespace root.ui.inputPostalCode
 */
root.ui.inputPostalCode = root.ui.inputPostalCode || {};
/**
 * チェックボックスで使用するオブジェクトのルート
 *
 * @namespace root.ui.checkBox
 */
root.ui.checkBox = root.ui.checkBox || {};
/**
 * ラジオボタンで使用するオブジェクトのルート
 *
 * @namespace root.ui.radio
 */
root.ui.radio = root.ui.radio || {};
/**
 * トグルボタンで使用するオブジェクトのルート
 *
 * @namespace root.ui.toggle
 */
root.ui.toggle = root.ui.toggle || {};
/**
 * ダイアログで使用するオブジェクトのルート
 *
 * @namespace root.ui.dialog
 */
root.ui.dialog = root.ui.dialog || {};
/**
 * インジゲータで使用するオブジェクトのルート
 *
 * @namespace root.ui.indicator
 */
root.ui.indicator = root.ui.indicator || {};
/**
 * パンくずで使用するオブジェクトのルート
 *
 * @namespace root.ui.breadCrumbs
 */
root.ui.breadCrumbs = root.ui.breadCrumbs || {};
/**
 * ページャーで使用するオブジェクトのルート
 *
 * @namespace root.ui.paging
 */
root.ui.paging = root.ui.paging || {};
/**
 * タブで使用するオブジェクトのルート
 *
 * @namespace root.ui.tab
 */
root.ui.tab = root.ui.tab || {};
/**
 * アコーディオンで使用するオブジェクトのルート
 *
 * @namespace root.ui.textSwitch
 */
root.ui.textSwitch = root.ui.textSwitch || {};
/**
 * ツールチップで使用するオブジェクトのルート
 *
 * @namespace root.ui.tooltip
 */
root.ui.tooltip = root.ui.tooltip || {};
/**
 * カレンダーで使用するオブジェクトのルート
 *
 * @namespace root.ui.calendar
 */
root.ui.calendar = root.ui.calendar || {};
/**
 * エラーダイアログで使用するオブジェクトのルート
 *
 * @namespace root.ui.errorDialog
 */
root.ui.errorDialog = root.ui.errorDialog || {};
/**
 * 表(table)関連で使用するオブジェクトのルート
 *
 * @namespace root.ui.table
 */
root.ui.table = root.ui.table || {};
/**
 * シンボルで使用するオブジェクトのルート
 *
 * @namespace root.ui.symbol
 */
root.ui.symbol = root.ui.symbol || {};
/**
 * ファイルアップロードで使用するオブジェクトのルート
 *
 * @namespace root.ui.buttonUploadFile
 */
root.ui.buttonUploadFile = root.ui.buttonUploadFile || {};
/**
 * 検索で使用するオブジェクトのルート
 *
 * @namespace root.ui.researchLink
 */
root.ui.researchLink = root.ui.researchLink || {};
/**
 * 業務支援系APIのルート
 *
 * @namespace root.util.operation
 */
root.util.operation = root.util.operation || {};
/**
 * ファイルアップロード系APIのルート
 *
 * @namespace root.util.fileUpload
 */
root.util.fileUpload = root.util.fileUpload || {};
/**
 * 共通処理系APIのルート
 *
 * @namespace root.util.common
 */
root.util.common = root.util.common || {};
/**
 * ダイアログで使用するオブジェクトのルート
 *
 * @namespace root.util.dialog
 */
root.util.dialog = root.util.dialog || {};
/**
 * テーブルで使用するオブジェクトのルート
 *
 * @namespace root.util.table
 */
root.util.table = root.util.table || {};
/**
 * 確認ダイアログで使用するオブジェクトのルート
 *
 * @namespace root.ui.confirm
 */
root.ui.confirm = root.ui.confirm || {};
/**
 * 時分入力で使用するオブジェクトのルート
 *
 * @namespace root.ui.time
 */
root.ui.time = root.ui.time || {};
/**
 * 業務支援系API（部品内共通）のルート
 *
 * @namespace root.ui.operation
 */
root.ui.operation = root.ui.operation || {};

/**
 * 初期化処理
 *
 * @return {Boolean} true(正常終了)
 */
root.ui.initialize = function() {
    'use strict';
    
    return true; // 成否(予約のみ)
}

/**
 * 画面を閉じる
 *
 * @return {Boolean} false(ポストバック防止)
 */
root.ui.header.closeWindow = function() {
    'use strict';

    // 閉じる処理
    window.open('about:blank', '_self').close();    	
    return false;
}

root.ui.datepicker = function() {
	$.datepicker.regional['ja'] = {
		closeText: '閉じる',
		prevText: '前へ',
		nextText: '次へ',
		currentText: '現在',
		monthNames: ['1月','2月','3月','4月','5月','6月',
		'7月','8月','9月','10月','11月','12月'],
		monthNamesShort:  ['1月','2月','3月','4月','5月','6月',
			'7月','8月','9月','10月','11月','12月'],
		dayNames: ['月曜日','火曜日','水曜日','木曜日','金曜日','土曜日','日曜日'],
		dayNamesShort: ['月','火','水','木','金','土','日'],
		dayNamesMin: ['月','火','水','木','金','土','日'],
		weekHeader: '週',
		dateFormat: 'yy-mm-dd',
		firstDay: 0,
		isRTL: false,
		showMonthAfterYear: false,
		yearSuffix: ''
	};
	$.datepicker.setDefaults($.datepicker.regional['ja']);
	$('.ui-datepicker').datepicker();
	
	$.timepicker.regional['ja'] = {
			timeOnlyTitle: '時間を選択',
			timeText: '時間',
			hourText: '時',
			minuteText: '分',
			secondText: '秒',
			millisecText: 'ミリ秒',
			microsecText: 'マイクロ秒',
			timezoneText: 'タイムゾーン',
			currentText: '現時刻',
			closeText: '閉じる',
			timeFormat: 'HH:mm:ss',
			timeSuffix: '',
			amNames: ['午前', 'AM', 'A'],
			pmNames: ['午後', 'PM', 'P'],
			isRTL: false
		};
	$.timepicker.setDefaults($.timepicker.regional['ja']);
	$('.ui-timepicker').timepicker();
}

//二重送信防止
root.ui.form = function() {
	$('form').on('submit', function () {
		$('input').css('pointer-events','none');
		$('button').css('pointer-events','none');
	});	
}



//日付入力項目の初期化
root.ui.datepicker();
//フォームの初期化
root.ui.form();
