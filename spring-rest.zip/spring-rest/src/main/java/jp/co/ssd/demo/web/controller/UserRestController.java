package jp.co.ssd.demo.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.ssd.demo.domain.entity.User;
import jp.co.ssd.demo.service.UserService;

@RestController
public class UserRestController {
    
    @Autowired
    private UserService userService;
    
    @RequestMapping("/rest")
    public String restHello() {
        return "This is RESTful API response";
    }
    
    @RequestMapping("/user/findAll")
    public List<User> findAllUserApi() {
        return userService.findAll();
    }
    
    @RequestMapping(value = "/user/save", consumes = "application/json", produces = "application/json")
    public void saveUser(@RequestBody User user) {
        userService.save(user.getUserSerialId(), user.getUserId(), user.getUserName(), user.getUserMail());
    }
}
