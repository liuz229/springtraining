package jp.co.ssd.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import jp.co.ssd.demo.domain.entity.User;
import jp.co.ssd.demo.domain.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
    	return userRepository.findAll();
    }
    
    public List<User> findByUserNameLike(String userName) {
    	return userRepository.findByUserNameLike(userName);
    }

    public List<User> findByUserNameQuery(String userName) {
    	return userRepository.findByUserNameLike(userName);
    }
    
    public List<User> findBySpecification(String userId, String userName, String userEmail) {
    	return userRepository.findAll(userId, userName, userEmail);
    }

    public List<User> findByUserId(String userId) {
    	return userRepository.findByUserId(userId);
    }
    
    public void deleteById(String userId) {
    	userRepository.delete(userId);

    }
    
    @Transactional
	public void save(Long userSerialId, String userId, String userName, String userEmail) {
	    if (StringUtils.isEmpty(userSerialId) || userSerialId == 0) {
	        User user = new User();
	        user.setUserId(userId);
	        user.setUserName(userName);
	        user.setUserMail(userEmail);
	        user.setUserPassword("");
	        user.setDepartmentSectionCd("07");
	        user.setUserPositionCd("00");
	        user.setApprovalUserId1("");
	        user.setApprovalUserId2("");
	        userRepository.insert(user);
	        
	    } else {
	        User user = findOne(userSerialId);
            user.setUserId(userId);
            user.setUserName(userName);
            user.setUserMail(userEmail);
            userRepository.update(user);
	    }
	    
	}

    public User findOne(Long userSerialId) {
        
        return userRepository.findOne(userSerialId);
    }

    public List<User> findByUserMailLike(String userMail) {
        // TODO Auto-generated method stub
        return userRepository.findByUserMailLike(userMail);
    }

    @Transactional(propagation = Propagation.NESTED)
    public void deleteBySerialId(Long userSerialId) {
        userRepository.deleteBySerialId(userSerialId);
        
    }

    @Transactional(propagation = Propagation.NESTED)
    public void insert(User user) {
        userRepository.insert(user);
    }
    
}
