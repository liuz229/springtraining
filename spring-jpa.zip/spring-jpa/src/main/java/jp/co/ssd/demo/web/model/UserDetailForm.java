package jp.co.ssd.demo.web.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class UserDetailForm {

	@NotBlank
	@Size(min = 7, max = 7)
	private String userId;
	@NotBlank
	@Size(max = 30)
	private String userName;
	@NotBlank
	@Size(max = 30)
	private String userEmail;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
}
