package jp.co.ssd.demo.domain.repository;

import org.springframework.data.jpa.domain.Specification;

import jp.co.ssd.demo.domain.entity.User;

public class UserSpecifications {

	public static Specification<User> findByUserId(String userId) {
	    return (root, query, cb) ->{ 
	        return cb.equal(root.get("userId"), userId);
	    };
	}
	public static Specification<User> findByUserName(String userName) {
	    return (root, query, cb) ->{ 
	        return cb.equal(root.get("userName"), userName);
	    };
	}
	public static Specification<User> findByUserEmail(String userEmail) {
	    return (root, query, cb) ->{ 
	        return cb.equal(root.get("userMail"), userEmail);
	    };
	}
}
