package jp.co.ssd.demo.domain.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.ssd.demo.domain.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
        
    @Query("select u from User u"
            + " where u.userName like %:userName%"
            + " order by u.userId")
    List<User> findByUserNameQuery(
            @Param("userName") String userName);
    
    List<User> findByUserNameLike(String userName);
}