package jp.co.ssd.demo.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jp.co.ssd.demo.domain.entity.User;
import jp.co.ssd.demo.domain.repository.UserRepository;
import jp.co.ssd.demo.domain.repository.UserSpecifications;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
    	return userRepository.findAll();
    }
    
    public List<User> findByUserNameLike(String userName) {
    	return userRepository.findByUserNameLike("%" + userName + "%");
    }

    public List<User> findByUserNameQuery(String userName) {
    	return userRepository.findByUserNameQuery(userName);
    }
    
    public List<User> findBySpecification(String userId, String userName, String userEmail) {
    	return userRepository.findAll(Specification.where(UserSpecifications.findByUserId(userId))
    			.or(UserSpecifications.findByUserName(userName))
    			.or(UserSpecifications.findByUserEmail(userEmail)));
    }

	public void save(String userId, String userName, String userEmail) {
		User user = new User();
		user.setUserId(userId);
		user.setUserName(userName);
		user.setUserMail(userEmail);
		user.setUserPassword("");
		user.setDepartmentSectionCd("07");
		user.setUserPositionCd("00");
		user.setApprovelUserId1("");
		user.setApprovelUserId2("");
		userRepository.save(user);
	}
}
