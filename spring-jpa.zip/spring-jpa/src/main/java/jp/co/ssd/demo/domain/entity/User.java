package jp.co.ssd.demo.domain.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USERS")
public class User implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "serial")
    private Long userSerialId;
    
    @Column(name = "USER_ID")
    private String userId;
    
    @Column(name = "USER_NAME")
    private String userName;
    
    @Column(name = "USER_PASSWORD")
    private String userPassword;
    
    @Column(name = "USER_MAIL")
    private String userMail;
    
    @Column(name = "DEPARTMENT_SECTION_CD")
    private String departmentSectionCd;
    
    @Column(name = "USER_POSITION_CD")
    private String userPositionCd;
    
    @Column(name = "APPROVAL_USER_ID1")
    private String approvelUserId1;
    
    @Column(name = "APPROVAL_USER_ID2")
    private String approvelUserId2;
    
    @Column(name = "ROLE_CD1")
    private String roleCd1;
    
    @Column(name = "ROLE_CD2")
    private String roleCd2;
    
    @Column(name = "ROLE_CD3")
    private String roleCd3;
    
    @Column(name = "ROLE_CD4")
    private String roleCd4;
    
    @Column(name = "ROLE_CD5")
    private String roleCd5;
    
    @Column(name = "CREATE_USER_ID")
    private String createUserId;
    
    @Column(name = "CREATE_TIMESTAMP")
    private Timestamp createTimestamp;
    
    @Column(name = "UPDATE_USER_ID")
    private String updateUserId;
    
	@Column(name = "UPDATE_TIMESTAMP")
    private Timestamp updateTimestamp;

	public Long getUserSerialId() {
		return userSerialId;
	}

	public void setUserSerialId(Long userSerialId) {
		this.userSerialId = userSerialId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserMail() {
		return userMail;
	}

	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}

	public String getDepartmentSectionCd() {
		return departmentSectionCd;
	}

	public void setDepartmentSectionCd(String departmentSectionCd) {
		this.departmentSectionCd = departmentSectionCd;
	}

	public String getUserPositionCd() {
		return userPositionCd;
	}

	public void setUserPositionCd(String userPositionCd) {
		this.userPositionCd = userPositionCd;
	}

	public String getApprovelUserId1() {
		return approvelUserId1;
	}

	public void setApprovelUserId1(String approvelUserId1) {
		this.approvelUserId1 = approvelUserId1;
	}

	public String getApprovelUserId2() {
		return approvelUserId2;
	}

	public void setApprovelUserId2(String approvelUserId2) {
		this.approvelUserId2 = approvelUserId2;
	}

	public String getRoleCd1() {
		return roleCd1;
	}

	public void setRoleCd1(String roleCd1) {
		this.roleCd1 = roleCd1;
	}

	public String getRoleCd2() {
		return roleCd2;
	}

	public void setRoleCd2(String roleCd2) {
		this.roleCd2 = roleCd2;
	}

	public String getRoleCd3() {
		return roleCd3;
	}

	public void setRoleCd3(String roleCd3) {
		this.roleCd3 = roleCd3;
	}

	public String getRoleCd4() {
		return roleCd4;
	}

	public void setRoleCd4(String roleCd4) {
		this.roleCd4 = roleCd4;
	}

	public String getRoleCd5() {
		return roleCd5;
	}

	public void setRoleCd5(String roleCd5) {
		this.roleCd5 = roleCd5;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}
}
