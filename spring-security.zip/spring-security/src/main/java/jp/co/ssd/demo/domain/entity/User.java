package jp.co.ssd.demo.domain.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class User implements Serializable {
    
    private Long userSerialId;
    
    private String userId;
    
    private String userName;
    
    private String userPassword;
    
    private String userMail;
    
    private String departmentSectionCd;
    
    private String userPositionCd;
    
    private String approvalUserId1;
    
    private String approvalUserId2;
    
    private String roleCd1;
    
    private String roleCd2;
    
    private String roleCd3;
    
    private String roleCd4;
    
    private String roleCd5;
    
    private String createUserId;
    
    private Timestamp createTimestamp;
    
    private String updateUserId;
    
    private Timestamp updateTimestamp;

	public Long getUserSerialId() {
		return userSerialId;
	}

	public void setUserSerialId(Long userSerialId) {
		this.userSerialId = userSerialId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserMail() {
		return userMail;
	}

	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}

	public String getDepartmentSectionCd() {
		return departmentSectionCd;
	}

	public void setDepartmentSectionCd(String departmentSectionCd) {
		this.departmentSectionCd = departmentSectionCd;
	}

	public String getUserPositionCd() {
		return userPositionCd;
	}

	public void setUserPositionCd(String userPositionCd) {
		this.userPositionCd = userPositionCd;
	}

	public String getApprovalUserId1() {
		return approvalUserId1;
	}

	public void setApprovalUserId1(String approvalUserId1) {
		this.approvalUserId1 = approvalUserId1;
	}

	public String getApprovalUserId2() {
		return approvalUserId2;
	}

	public void setApprovalUserId2(String approvalUserId2) {
		this.approvalUserId2 = approvalUserId2;
	}

	public String getRoleCd1() {
		return roleCd1;
	}

	public void setRoleCd1(String roleCd1) {
		this.roleCd1 = roleCd1;
	}

	public String getRoleCd2() {
		return roleCd2;
	}

	public void setRoleCd2(String roleCd2) {
		this.roleCd2 = roleCd2;
	}

	public String getRoleCd3() {
		return roleCd3;
	}

	public void setRoleCd3(String roleCd3) {
		this.roleCd3 = roleCd3;
	}

	public String getRoleCd4() {
		return roleCd4;
	}

	public void setRoleCd4(String roleCd4) {
		this.roleCd4 = roleCd4;
	}

	public String getRoleCd5() {
		return roleCd5;
	}

	public void setRoleCd5(String roleCd5) {
		this.roleCd5 = roleCd5;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}
}
