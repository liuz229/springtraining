package jp.co.ssd.demo.web.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.GlobalAuthenticationConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import jp.co.ssd.demo.service.LoginService;
import jp.co.ssd.demo.service.UserService;

@EnableWebSecurity
public class SecurityConfig {
    /**
     * BASIC認証を使用するかどうか？
     */
    @Value("${usebasicauthentication}")
    private boolean useBasicAuthentication;

    @Autowired
    private LoginService loginService;

    @Configuration
    public class CommonSecurityConfig extends WebSecurityConfigurerAdapter {

        @Override
        public void configure(WebSecurity web) throws Exception {
          System.out.println("CommonSecurityConfig#configure(WebSecurity)");
          // セキュリティ設定を無視するリクエスト設定
          // 静的リソース(images、css、javascript)に対するアクセスはセキュリティ設定を無視する
          web.ignoring().antMatchers("/images/**", "/css/**", "/js/**");
        }      
        
        @Override
        protected void configure(HttpSecurity http) throws Exception {
          System.out.println("CommonSecurityConfig#configure(HttpSecurity)");
          // 認証が必要な URL を指定
          http.antMatcher("/**");
          if (useBasicAuthentication) {
              // BASIC 認証を有効化
              http.httpBasic();
              // BASIC 認証の情報は毎回送信されるためセッション管理は不要
              http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
          } else {
              http.formLogin().successForwardUrl("/loginSucess");
          }
          
          // CSRF 対策機能を無効化
          http.csrf().disable();
          // 指定した URL を対象とした認証を有効化
          http.authorizeRequests().anyRequest().authenticated();
        }
/*
        @Override
        protected void configure(AuthenticationManagerBuilder auth) throws Exception {
            System.out.println("CommonSecurityConfig#configure(AuthenticationManagerBuilder)");
            auth.userDetailsService(loginService)
            // 入力値をbcryptでハッシュ化した値でパスワード認証を行う
            .passwordEncoder(passwordEncoder());
        }
        
        @Bean
        public PasswordEncoder passwordEncoder() {
            return new BCryptPasswordEncoder();
        }
*/    }
}
