package jp.co.ssd.demo.service;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import jp.co.ssd.demo.domain.entity.User;
import jp.co.ssd.demo.domain.repository.UserRepository;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
    	return userRepository.findAll();
    }
    
    public List<User> findByUserNameLike(String userName) {
    	return userRepository.findByUserNameLike(userName);
    }

    public List<User> findByUserNameQuery(String userName) {
    	return userRepository.findByUserNameLike(userName);
    }
    
    public List<User> findBySpecification(String userId, String userName, String userEmail) {
    	return userRepository.findAll(userId, userName, userEmail);
    }

    public List<User> findByUserId(String userId) {
    	return userRepository.findByUserId(userId);
    }
    
    public User findOneByUserId(String userId) {
        List<User> list = findByUserId(userId);
        
        return list.isEmpty() ? null : list.get(0);
    }
    
    public void deleteById(String userId) {
    	userRepository.delete(userId);

    }
    
    @Transactional
	public void save(Long userSerialId, String userId, String userName, String userEmail) {
	    if (StringUtils.isEmpty(userSerialId) || userSerialId == 0) {
	        User user = new User();
	        user.setUserId(userId);
	        user.setUserName(userName);
	        user.setUserMail(userEmail);
	        user.setUserPassword("");
	        user.setDepartmentSectionCd("07");
	        user.setUserPositionCd("00");
	        user.setApprovalUserId1("");
	        user.setApprovalUserId2("");
	        userRepository.insert(user);
	        
	    } else {
	        User user = findOne(userSerialId);
            user.setUserId(userId);
            user.setUserName(userName);
            user.setUserMail(userEmail);
            userRepository.update(user);
	    }
	    
	}

    public User findOne(Long userSerialId) {
        
        return userRepository.findOne(userSerialId);
    }

    public List<User> findByUserMailLike(String userMail) {
        // TODO Auto-generated method stub
        return userRepository.findByUserMailLike(userMail);
    }

    @Transactional(propagation = Propagation.NESTED)
    public void deleteBySerialId(Long userSerialId) {
        userRepository.deleteBySerialId(userSerialId);
        
    }

    @Transactional(rollbackFor = Exception.class)
    public void insert3() throws Exception {
        // Insert user1    
        User user = new User();
        user.setUserId("TEST001");
        user.setUserName("TEST001");
        user.setUserMail("TEST001@email.com");
        user.setUserPassword("");
        user.setDepartmentSectionCd("07");
        user.setUserPositionCd("00");
        user.setApprovalUserId1("");
        user.setApprovalUserId2("");
        userRepository.insert(user);
        
        User retUser = findByUserId("TEST001").get(0);
        System.out.println("USER1 ID=" + retUser.getUserId());
        
        
        // Insert user2    
        user = new User();
        user.setUserId("TEST002");
        user.setUserName("TEST002");
        user.setUserMail("TEST002@email.com");
        user.setUserPassword("");
        user.setDepartmentSectionCd("07");
        user.setUserPositionCd("00");
        user.setApprovalUserId1("");
        user.setApprovalUserId2("");
        userRepository.insert(user);
        retUser = findByUserId("TEST002").get(0);
        System.out.println("USER2 ID=" + retUser.getUserId());
        
        int i = 1;       
        //if (i == 1) throw new RuntimeException("test error");
        if (i == 1) throw new Exception("test error");
        // Insert user3    
        user = new User();
        user.setUserId("TEST003");
        user.setUserName("TEST003");
        user.setUserMail("TEST003@email.com");
        user.setUserPassword("");
        user.setDepartmentSectionCd("07");
        user.setUserPositionCd("00");
        user.setApprovalUserId1("");
        user.setApprovalUserId2("");
        userRepository.insert(user);
        retUser = findByUserId("TEST003").get(0);
        System.out.println("USER3 ID=" + retUser.getUserId());
        
    }
}
