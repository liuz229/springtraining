package jp.co.ssd.demo.web.model;

import java.util.List;

import jp.co.ssd.demo.domain.entity.User;

public class UserListForm {

	private String searchUserName;
	
	private String searchUserId;
	
	private String searchUserEmail;
	
	private List<User> userList;
	
	private String message;

	public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSearchUserName() {
		return searchUserName;
	}

	public void setSearchUserName(String searchUserName) {
		this.searchUserName = searchUserName;
	}

	public String getSearchUserId() {
		return searchUserId;
	}

	public void setSearchUserId(String searchUserId) {
		this.searchUserId = searchUserId;
	}

	public String getSearchUserEmail() {
		return searchUserEmail;
	}

	public void setSearchUserEmail(String searchUserEmail) {
		this.searchUserEmail = searchUserEmail;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}
	
}
