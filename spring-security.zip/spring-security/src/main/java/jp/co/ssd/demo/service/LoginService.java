package jp.co.ssd.demo.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import jp.co.ssd.demo.domain.entity.User;

@Service
public class LoginService implements UserDetailsService {

    //初期パスワード：Ssd#2020
    //private static final String INIT_PASSWORD = "$2a$10$hBot704MSjVijSdRYRlYZuxApzMZsIRoF7yQntcOhCwqVPkUqTmcO";

    @Autowired
    private UserService userService;

    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        User user = userService.findOneByUserId(userId);
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("User not found");
        }
        return new org.springframework.security.core.userdetails.User(
                user.getUserId(), 
                user.getUserPassword(), 
                AuthorityUtils.createAuthorityList("ROLE_USER"));
    }
}
